namespace ASPValidering.Models;

public class ValiViewModel
{
    public string Tal { get; set; }
    public string Regler { get; set; }
    public string? Message { get; set; }
}